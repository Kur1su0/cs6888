python3 fl_Op2.py tcas_out/P tcas_out/F
